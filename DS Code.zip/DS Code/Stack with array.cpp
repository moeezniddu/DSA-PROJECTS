#include <iostream>

using namespace std;

class Stack {
private:
    int* array;
    int capacity;
    int top;

public:
    Stack(int size) : capacity(size), top(-1) {
        array = new int[capacity];
    }

    ~Stack() {
        delete[] array;
    }

    // Check if the stack is empty
    bool isEmpty() {
        return top == -1;
    }

    // Check if the stack is full
    bool isFull() {
        return top == capacity - 1;
    }

    // Push an element onto the stack
    void push(int value) {
        if (isFull()) {
            cout << "Stack Overflow: Cannot push element onto a full stack." << endl;
            return;
        }

        array[++top] = value;
    }

    // Pop an element from the stack
    void pop() {
        if (isEmpty()) {
            cout << "Stack Underflow: Cannot pop element from an empty stack." << endl;
            return;
        }

        --top;
    }

    // Get the top element of the stack without removing it
    int peek() {
        if (isEmpty()) {
            cout << "Stack is empty." << endl;
            return -1; // You might choose a different way to handle this case
        }

        return array[top];
    }

    // Display the elements of the stack
    void display() {
        if (isEmpty()) {
            cout << "Stack is empty." << endl;
            return;
        }

        cout << "Stack: ";
        for (int i = 0; i <= top; ++i) {
            cout << array[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    Stack myStack(5);

    myStack.push(1);
    myStack.push(2);
    myStack.push(3);

    myStack.display();

    cout << "Top element: " << myStack.peek() << endl;

    myStack.pop();
    myStack.display();

    cout << "Is the stack empty? " << (myStack.isEmpty() ? "Yes" : "No") << endl;

    return 0;
}
