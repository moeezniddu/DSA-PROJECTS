#include <iostream>

using namespace std;

class MaxHeap {
private:
    int *heap;
    int capacity;
    int size;

    // Helper function to heapify a subtree with the given root at index i
    void heapify(int i) { //heapifyDown
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int largest = i;

        // Compare with left child
        if (left < size && heap[left] > heap[largest]) {
            largest = left;
        }

        // Compare with right child
        if (right < size && heap[right] > heap[largest]) {
            largest = right;
        }

        // If the largest is not the root, swap and continue heapifying
        if (largest != i) {
            swap(heap[i], heap[largest]);
            heapify(largest);
        }
    }

public:
    // Constructor
    MaxHeap(int capacity) {
        this->capacity = capacity;
        this->heap = new int[capacity];
        this->size = 0;
    }

    // Destructor
    ~MaxHeap() {
        delete[] heap;
    }

    // Function to insert a new element into the heap
    void insert(int value) {
        if (size == capacity) {
            cout << "Heap is full. Cannot insert." << endl;
            return;
        }

        heap[size] = value;

        int index = size;
        while (index > 0) { //heapifyUP
            int parent = (index - 1) / 2;
            if (heap[index] > heap[parent]) {
                swap(heap[index], heap[parent]);
                index = parent;
            } else {
                break;
            }
        }

        size++;
    }

    // Function to delete the maximum element (root) from the heap
    void deleteMax() {
        if (size == 0) {
            cout << "Heap is empty. Cannot delete." << endl;
            return;
        }

        // Replace the root with the last element
        heap[0] = heap[size - 1];
        size--;

        // Heapify the root
        heapify(0);
    }

    // Function to get the maximum element (root) of the heap
    int getMax() {
        if (size == 0) {
            cout << "Heap is empty." << endl;
            return -1; // You might choose a different way to handle this case
        }

        return heap[0];
    }

    // Function to check if the heap is empty
    bool isEmpty() {
        return size == 0;
    }

    // Function to display the elements of the heap
    void display() {
        if (isEmpty()) {
            cout << "Heap is empty." << endl;
            return;
        }

        cout << "Max Heap: ";
        for (int i = 0; i < size; i++) {
            cout << heap[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    MaxHeap maxHeap(7); // 2^level - 1 (max nodes in level)

    maxHeap.insert(10);
    maxHeap.insert(30);
    maxHeap.insert(20);
    maxHeap.insert(50);
    maxHeap.insert(40);

    maxHeap.display();

    cout << "Max element: " << maxHeap.getMax() << endl;

    maxHeap.deleteMax();
    maxHeap.display();

    return 0;
}
