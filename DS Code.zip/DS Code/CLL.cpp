#include <iostream>

using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) : data(value), next(nullptr) {}
};

class CircularLinkedList {
private:
    Node* head;

public:
    CircularLinkedList() : head(nullptr) {}

    ~CircularLinkedList() {
        // Destructor to free memory when the list is destroyed
        if (head != nullptr) {
            Node* current = head->next;

            while (current != nullptr && current != head) {
                Node* temp = current;
                current = current->next;
                delete temp;
            }

            delete head;
        }
    }

    // Append a new element to the end of the list
    void append(int value) {
        Node* newNode = new Node(value);
        if (head == nullptr) {
            head = newNode;
            head->next = head; // Circular link to itself
        } else {
            Node* current = head;
            while (current->next != head) {
                current = current->next;
            }
            current->next = newNode;
            newNode->next = head; // Circular link to head
        }
    }

    // Prepend a new element to the beginning of the list
    void prepend(int value) {
        Node* newNode = new Node(value);
        if (head == nullptr) {
            head = newNode;
            head->next = head; // Circular link to itself
        } else {
            Node* current = head;
            while (current->next != head) {
                current = current->next;
            }
            newNode->next = head;
            head = newNode;
            current->next = head; // Update circular link
        }
    }

    // Insert a new element at a specific position in the list
    void insertAt(int value, int position) {
        if (position < 0) {
            cout << "Invalid position" << endl;
            return;
        }

        Node* newNode = new Node(value);
        if (position == 0) {
            prepend(value);
        } else {
            Node* current = head;
            for (int i = 0; i < position - 1 && current != nullptr; ++i) {
                current = current->next;
            }

            if (current == nullptr) {
                cout << "Invalid position" << endl;
                delete newNode;
                return;
            }

            newNode->next = current->next;
            current->next = newNode;
        }
    }

    // Remove an element with a specific value from the list
    void remove(int value) {
        if (head == nullptr) {
            cout << "List is empty" << endl;
            return;
        }

        Node* current = head;
        Node* prev = nullptr;

        // Search for the element
        do {
            if (current->data == value) {
                break;
            }
            prev = current;
            current = current->next;
        } while (current != head);

        if (current == head && current->data != value) {
            cout << "Element not found" << endl;
            return;
        }

        // Remove the element
        if (prev != nullptr) {
            prev->next = current->next;
        } else {
            // If the head is being removed, update the head
            head = current->next;
            if (head == current) {
                // If there was only one element, set head to nullptr
                head = nullptr;
            }
        }

        delete current;
    }

    // Search for an element with a specific value in the list
    bool search(int value) {
        if (head == nullptr) {
            return false;
        }

        Node* current = head;

        do {
            if (current->data == value) {
                return true;
            }
            current = current->next;
        } while (current != head);

        return false;
    }

    // Get the size (number of elements) of the list
    int size() {
        if (head == nullptr) {
            return 0;
        }

        int count = 0;
        Node* current = head;

        do {
            ++count;
            current = current->next;
        } while (current != head);

        return count;
    }

    // Display the elements of the list
    void display() {
        if (head == nullptr) {
            cout << "List is empty" << endl;
            return;
        }

        Node* current = head;

        do {
            cout << current->data << " ";
            current = current->next;
        } while (current != head);

        cout << endl;
    }
};

int main() {
    CircularLinkedList myList;
    myList.append(1);
    myList.append(2);
    myList.append(3);

    cout << "Circular Linked List: ";
    myList.display();

    myList.prepend(0);
    myList.insertAt(2, 1);

    cout << "Circular Linked List after modifications: ";
    myList.display();

    cout << "Size of Circular Linked List: " << myList.size() << endl;

    myList.remove(2);

    cout << "Circular Linked List after removal: ";
    myList.display();

    cout << "Is 3 present in the Circular Linked List? " << (myList.search(3) ? "Yes" : "No") << endl;

    return 0;
}
