#include <iostream>

using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) : data(value), next(nullptr) {}
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList() : head(nullptr) {}

    ~LinkedList() {
        // Destructor to free memory when the list is destroyed
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }

    // Append a new element to the end of the list
    void append(int value) {
        Node* newNode = new Node(value);
        if (head == nullptr) {
            head = newNode;
        } else {
            Node* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = newNode;
        }
    }

    // Prepend a new element to the beginning of the list
    void prepend(int value) {
        Node* newNode = new Node(value);
        newNode->next = head;
        head = newNode;
    }

    // Insert a new element at a specific position in the list
    void insertAt(int value, int position) {
        if (position < 0) {
            cout << "Invalid position" << endl;
            return;
        }

        Node* newNode = new Node(value);
        if (position == 0) {
            newNode->next = head;
            head = newNode;
        } else {
            Node* current = head;
            for (int i = 0; i < position - 1 && current != nullptr; ++i) {
                current = current->next;
            }

            if (current == nullptr) {
                cout << "Invalid position" << endl;
                delete newNode;
                return;
            }

            newNode->next = current->next;
            current->next = newNode;
        }
    }

    // Remove an element with a specific value from the list
    void remove(int value) {
        Node* current = head;
        Node* prev = nullptr;

        while (current != nullptr && current->data != value) {
            prev = current;
            current = current->next;
        }

        if (current == nullptr) {
            cout << "Element not found" << endl;
            return;
        }

        if (prev == nullptr) {
            head = current->next;
        } else {
            prev->next = current->next;
        }

        delete current;
    }

    // Search for an element with a specific value in the list
    bool search(int value) {
        Node* current = head;
        while (current != nullptr) {
            if (current->data == value) {
                return true;
            }
            current = current->next;
        }
        return false;
    }

    // Get the size (number of elements) of the list
    int size() {
        int count = 0;
        Node* current = head;
        while (current != nullptr) {
            ++count;
            current = current->next;
        }
        return count;
    }

    // Display the elements of the list
    void display() {
        Node* current = head;
        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};

int main() {
    LinkedList myList;
    myList.append(1);
    myList.append(2);
    myList.append(3);

    cout << "Linked List: ";
    myList.display();

    myList.prepend(0);
    myList.insertAt(2, 1);

    cout << "Linked List after modifications: ";
    myList.display();

    cout << "Size of Linked List: " << myList.size() << endl;

    myList.remove(2);

    cout << "Linked List after removal: ";
    myList.display();

    cout << "Is 3 present in the Linked List? " << (myList.search(3) ? "Yes" : "No") << endl;

    return 0;
}
