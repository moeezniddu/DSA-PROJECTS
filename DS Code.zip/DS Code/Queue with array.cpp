#include <iostream>

using namespace std;

class Queue {
private:
    int* array;
    int capacity;
    int front;
    int rear;
    int size;

public:
    Queue(int queueSize) : capacity(queueSize), front(-1), rear(-1), size(0) {
        array = new int[capacity];
    }

    ~Queue() {
        delete[] array;
    }

    // Check if the queue is empty
    bool isEmpty() {
        return size == 0;
    }

    // Check if the queue is full
    bool isFull() {
        return size == capacity;
    }

    // Enqueue (add) an element to the rear of the queue
    void enqueue(int value) {
        if (isFull()) {
            cout << "Queue Overflow: Cannot enqueue element into a full queue." << endl;
            return;
        }

        if (isEmpty()) {
            front = rear = 0;
        } else {
            rear = (rear + 1) % capacity;
        }

        array[rear] = value;
        ++size;
    }

    // Dequeue (remove) an element from the front of the queue
    void dequeue() {
        if (isEmpty()) {
            cout << "Queue Underflow: Cannot dequeue element from an empty queue." << endl;
            return;
        }

        if (front == rear) {
            // If there's only one element in the queue
            front = rear = -1;
        } else {
            front = (front + 1) % capacity;
        }

        --size;
    }

    // Get the front element of the queue without removing it
    int peek() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return -1; // You might choose a different way to handle this case
        }

        return array[front];
    }

    // Display the elements of the queue
    void display() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return;
        }

        cout << "Queue: ";
        int i = front;
        do {
            cout << array[i] << " ";
            i = (i + 1) % capacity;
        } while (i != (rear + 1) % capacity);

        cout << endl;
    }
};

int main() {
    Queue myQueue(5);

    myQueue.enqueue(1);
    myQueue.enqueue(2);
    myQueue.enqueue(3);

    myQueue.display();

    cout << "Front element: " << myQueue.peek() << endl;

    myQueue.dequeue();
    myQueue.display();

    cout << "Is the queue empty? " << (myQueue.isEmpty() ? "Yes" : "No") << endl;

    return 0;
}
