#include <iostream>
#include <queue>

using namespace std;

class Node {
public:
    int key;
    Node* left;
    Node* right;

    Node(int value) : key(value), left(nullptr), right(nullptr) {}
};

class BST {
private:
    Node* root;

    // Helper function to insert a key into the BST
    Node* insert(Node* node, int key) {
        if (node == nullptr) {
            return new Node(key);
        }

        if (key < node->key) {
            node->left = insert(node->left, key);
        } else if (key > node->key) {
            node->right = insert(node->right, key);
        }

        return node;
    }

    // Helper function to find the minimum key in a subtree
    Node* findMin(Node* node) {
        while (node->left != nullptr) {
            node = node->left;
        }
        return node;
    }

    // Helper function to delete a key from the BST
    Node* remove(Node* root, int key) {
        if (root == nullptr) {
            return root;
        }

        if (key < root->key) {
            root->left = remove(root->left, key);
        } else if (key > root->key) {
            root->right = remove(root->right, key);
        } else {
            if (root->left == nullptr) {
                Node* temp = root->right;
                delete root;
                return temp;
            } else if (root->right == nullptr) {
                Node* temp = root->left;
                delete root;
                return temp;
            }

            Node* temp = findMin(root->right);
            root->key = temp->key;
            root->right = remove(root->right, temp->key);
        }

        return root;
    }

    // Helper function to perform in-order traversal
    void inOrderTraversal(Node* node) {
        if (node != nullptr) {
            inOrderTraversal(node->left);
            cout << node->key << " ";
            inOrderTraversal(node->right);
        }
    }

    // Helper function to perform pre-order traversal
    void preOrderTraversal(Node* node) {
        if (node != nullptr) {
            cout << node->key << " ";
            preOrderTraversal(node->left);
            preOrderTraversal(node->right);
        }
    }

    // Helper function to perform post-order traversal
    void postOrderTraversal(Node* node) {
        if (node != nullptr) {
            postOrderTraversal(node->left);
            postOrderTraversal(node->right);
            cout << node->key << " ";
        }
    }

    // Helper function to perform level-order traversal
    void levelOrderTraversal(Node* root) {
        if (root == nullptr) {
            return;
        }

        queue<Node*> q;
        q.push(root);

        while (!q.empty()) {
            Node* current = q.front();
            cout << current->key << " ";
            q.pop();

            if (current->left != nullptr) {
                q.push(current->left);
            }

            if (current->right != nullptr) {
                q.push(current->right);
            }
        }
    }

public:
    BST() : root(nullptr) {}

    // Function to insert a key into the BST
    void insert(int key) {
        root = insert(root, key);
    }

    // Function to delete a key from the BST
    void remove(int key) {
        root = remove(root, key);
    }

    // Function to search for a key in the BST
    bool search(int key) {
        Node* current = root;
        while (current != nullptr) {
            if (key == current->key) {
                return true;
            } else if (key < current->key) {
                current = current->left;
            } else {
                current = current->right;
            }
        }
        return false;
    }

    // Function to perform in-order traversal of the BST
    void inOrderTraversal() {
        inOrderTraversal(root);
        cout << endl;
    }

    // Function to perform pre-order traversal of the BST
    void preOrderTraversal() {
        preOrderTraversal(root);
        cout << endl;
    }

    // Function to perform post-order traversal of the BST
    void postOrderTraversal() {
        postOrderTraversal(root);
        cout << endl;
    }

    // Function to perform level-order traversal of the BST
    void levelOrderTraversal() {
        levelOrderTraversal(root);
        cout << endl;
    }
};

int main() {
    BST myBST;

    myBST.insert(50);
    myBST.insert(30);
    myBST.insert(70);
    myBST.insert(20);
    myBST.insert(40);
    myBST.insert(60);
    myBST.insert(80);

    cout << "In-Order Traversal: ";
    myBST.inOrderTraversal();

    cout << "Pre-Order Traversal: ";
    myBST.preOrderTraversal();

    cout << "Post-Order Traversal: ";
    myBST.postOrderTraversal();

    cout << "Level-Order Traversal: ";
    myBST.levelOrderTraversal();

    cout << "Is 40 present in the BST? " << (myBST.search(40) ? "Yes" : "No") << endl;

    myBST.remove(30);

    cout << "In-Order Traversal after removing 30: ";
    myBST.inOrderTraversal();

    return 0;
}
