#include <iostream>
#include <list>
#include <queue>

using namespace std;

class Graph {
private:
    int vertices;
    list<int>* adjacencyList;

public:
    // Constructor to initialize the graph with a given number of vertices
    Graph(int vertices) : vertices(vertices), adjacencyList(new list<int>[vertices]) {}

    // Function to add an edge between two vertices
    void addEdge(int source, int destination) {
        if (source >= 0 && source < vertices && destination >= 0 && destination < vertices) {
            adjacencyList[source].push_back(destination);
            adjacencyList[destination].push_back(source);
        } else {
            cout << "Invalid vertices." << endl;
        }
    }

    // Function to display the adjacency list
    void display() {
        cout << "Adjacency List:" << endl;
        for (int i = 0; i < vertices; ++i) {
            cout << i << ": ";
            for (int neighbor : adjacencyList[i]) {
                cout << neighbor << " ";
            }
            cout << endl;
        }
    }

    // Helper function for depth-first traversal
    void dfsUtil(int vertex, vector<bool>& visited) {
        cout << vertex << " ";
        visited[vertex] = true;

        for (int neighbor : adjacencyList[vertex]) {
            if (!visited[neighbor]) {
                dfsUtil(neighbor, visited);
            }
        }
    }

    // Function to perform depth-first traversal (DFS)
    void dfs(int startVertex) {
        if (startVertex >= 0 && startVertex < vertices) {
            vector<bool> visited(vertices, false);
            cout << "DFS starting from vertex " << startVertex << ": ";
            dfsUtil(startVertex, visited);
            cout << endl;
        } else {
            cout << "Invalid starting vertex." << endl;
        }
    }

    // Function to perform breadth-first traversal (BFS)
    void bfs(int startVertex) {
        if (startVertex >= 0 && startVertex < vertices) {
            vector<bool> visited(vertices, false);
            queue<int> q;

            cout << "BFS starting from vertex " << startVertex << ": ";
            q.push(startVertex);
            visited[startVertex] = true;

            while (!q.empty()) {
                int currentVertex = q.front();
                q.pop();
                cout << currentVertex << " ";

                for (int neighbor : adjacencyList[currentVertex]) {
                    if (!visited[neighbor]) {
                        q.push(neighbor);
                        visited[neighbor] = true;
                    }
                }
            }

            cout << endl;
        } else {
            cout << "Invalid starting vertex." << endl;
        }
    }
};

int main() {
    // Create a graph with 5 vertices
    Graph graph(5);

    // Add edges to the graph
    graph.addEdge(0, 1);
    graph.addEdge(0, 2);
    graph.addEdge(1, 3);
    graph.addEdge(2, 4);

    // Display the adjacency list
    graph.display();

    // Perform depth-first traversal starting from vertex 0
    graph.dfs(0);

    // Perform breadth-first traversal starting from vertex 0
    graph.bfs(0);

    return 0;
}
