#include <iostream>
#include <vector>
#include <queue>

using namespace std;

class Graph {
private:
    int vertices;
    vector<vector<int>> adjacencyMatrix;

public:
    // Constructor to initialize the graph with a given number of vertices
    Graph(int vertices) : vertices(vertices), adjacencyMatrix(vertices, vector<int>(vertices, 0)) {}

    // Function to add an edge between two vertices
    void addEdge(int source, int destination) {
        if (source >= 0 && source < vertices && destination >= 0 && destination < vertices) {
            adjacencyMatrix[source][destination] = 1;
            adjacencyMatrix[destination][source] = 1;
        } else {
            cout << "Invalid vertices." << endl;
        }
    }

    // Function to display the adjacency matrix
    void display() {
        cout << "Adjacency Matrix:" << endl;
        for (int i = 0; i < vertices; ++i) {
            for (int j = 0; j < vertices; ++j) {
                cout << adjacencyMatrix[i][j] << " ";
            }
            cout << endl;
        }
    }

    // Helper function for depth-first traversal
    void dfsUtil(int vertex, vector<bool>& visited) {
        cout << vertex << " ";
        visited[vertex] = true;

        for (int i = 0; i < vertices; ++i) {
            if (adjacencyMatrix[vertex][i] && !visited[i]) {
                dfsUtil(i, visited);
            }
        }
    }

    // Function to perform depth-first traversal (DFS)
    void dfs(int startVertex) {
        if (startVertex >= 0 && startVertex < vertices) {
            vector<bool> visited(vertices, false);
            cout << "DFS starting from vertex " << startVertex << ": ";
            dfsUtil(startVertex, visited);
            cout << endl;
        } else {
            cout << "Invalid starting vertex." << endl;
        }
    }

    // Function to perform breadth-first traversal (BFS)
    void bfs(int startVertex) {
        if (startVertex >= 0 && startVertex < vertices) {
            vector<bool> visited(vertices, false);
            queue<int> q;

            cout << "BFS starting from vertex " << startVertex << ": ";
            q.push(startVertex);
            visited[startVertex] = true;

            while (!q.empty()) {
                int currentVertex = q.front();
                q.pop();
                cout << currentVertex << " ";

                for (int i = 0; i < vertices; ++i) {
                    if (adjacencyMatrix[currentVertex][i] && !visited[i]) {
                        q.push(i);
                        visited[i] = true;
                    }
                }
            }

            cout << endl;
        } else {
            cout << "Invalid starting vertex." << endl;
        }
    }
};

int main() {
    // Create a graph with 5 vertices
    Graph graph(5);

    // Add edges to the graph
    graph.addEdge(0, 1);
    graph.addEdge(0, 2);
    graph.addEdge(1, 3);
    graph.addEdge(2, 4);

    // Display the adjacency matrix
    graph.display();

    // Perform depth-first traversal starting from vertex 0
    graph.dfs(0);

    // Perform breadth-first traversal starting from vertex 0
    graph.bfs(0);

    return 0;
}
