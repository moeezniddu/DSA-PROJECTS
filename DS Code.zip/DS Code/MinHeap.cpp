#include <iostream>

using namespace std;

class MinHeap {
private:
    static const int MAX_SIZE = 100;  // Choose a maximum size for the array
    int heap[MAX_SIZE];
    int size;

    // Helper function to heapify a subtree with the given root at index i
    void heapify(int i) { //heapifDown
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int smallest = i;

        // Compare with left child
        if (left < size && heap[left] < heap[smallest]) {
            smallest = left;
        }

        // Compare with right child
        if (right < size && heap[right] < heap[smallest]) {
            smallest = right;
        }

        // If the smallest is not the root, swap and continue heapifying
        if (smallest != i) {
            swap(heap[i], heap[smallest]);
            heapify(smallest);
        }
    }

public:
    MinHeap() : size(0) {}

    // Function to insert a new element into the heap
    void insert(int value) {
        if (size >= MAX_SIZE) {
            cout << "Heap is full. Cannot insert." << endl;
            return;
        }

        heap[size] = value;
        int index = size;
        size++;

        while (index > 0) { //heapifyUP
            int parent = (index - 1) / 2;
            if (heap[index] < heap[parent]) {
                swap(heap[index], heap[parent]);
                index = parent;
            } else {
                break;
            }
        }
    }

    // Function to delete the minimum element (root) from the heap
    void deleteMin() {
        if (size == 0) {
            cout << "Heap is empty. Cannot delete." << endl;
            return;
        }

        // Replace the root with the last element
        size--;
        heap[0] = heap[size];

        // Heapify the root
        heapify(0);
    }

    // Function to get the minimum element (root) of the heap
    int getMin() {
        if (size == 0) {
            cout << "Heap is empty." << endl;
            return -1; // You might choose a different way to handle this case
        }

        return heap[0];
    }

    // Function to check if the heap is empty
    bool isEmpty() {
        return size == 0;
    }

    // Function to display the elements of the heap
    void display() {
        if (isEmpty()) {
            cout << "Heap is empty." << endl;
            return;
        }

        cout << "Min Heap: ";
        for (int i = 0; i < size; i++) {
            cout << heap[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    MinHeap minHeap;

    minHeap.insert(10);
    minHeap.insert(30);
    minHeap.insert(20);
    minHeap.insert(50);
    minHeap.insert(40);

    minHeap.display();

    cout << "Min element: " << minHeap.getMin() << endl;

    minHeap.deleteMin();
    minHeap.display();

    return 0;
}
