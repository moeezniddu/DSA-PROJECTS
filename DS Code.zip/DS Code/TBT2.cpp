#include <iostream>

class ThreadedBinaryTreeNode {
public:
    int data;
    ThreadedBinaryTreeNode* left;
    ThreadedBinaryTreeNode* right;
    bool isThreaded;

    ThreadedBinaryTreeNode(int value) : data(value), left(nullptr), right(nullptr), isThreaded(false) {}
};

class ThreadedBinaryTree {
private:
    ThreadedBinaryTreeNode* root;

    // Helper function to perform in-order traversal using threaded pointers
    void inOrderTraversal(ThreadedBinaryTreeNode* node) {
        while (node != nullptr) {
            while (node->left != nullptr) {
                node = node->left;
            }

            std::cout << node->data << " ";

            if (node->isThreaded) {
                node = node->right;
            } else {
                node = node->right;
            }
        }
    }

    // Helper function to find the node with the minimum value in the tree
    ThreadedBinaryTreeNode* findMin(ThreadedBinaryTreeNode* node) {
        while (node->left != nullptr) {
            node = node->left;
        }
        return node;
    }

    // Helper function to find the in-order successor of a given node
    ThreadedBinaryTreeNode* findSuccessor(ThreadedBinaryTreeNode* node) {
        if (node->isThreaded || node->right == nullptr) {
            return node->right;
        } else {
            return findMin(node->right);
        }
    }

    // Helper function to perform post-order traversal and delete nodes
    void postOrderDelete(ThreadedBinaryTreeNode* node) {
        if (node != nullptr) {
            postOrderDelete(node->left);
            postOrderDelete(node->right);
            delete node;
        }
    }

    // Helper function to remove a node with a given value from the tree
    ThreadedBinaryTreeNode* removeNode(ThreadedBinaryTreeNode* node, int value) {
        if (node == nullptr) {
            return nullptr;
        }

        if (value < node->data) {
            node->left = removeNode(node->left, value);
        } else if (value > node->data) {
            node->right = removeNode(node->right, value);
        } else {
            // Node with the value found, perform removal

            if (node->isThreaded) {
                // If the node has only one child or no child
                ThreadedBinaryTreeNode* temp = node;
                if (node->left == nullptr) {
                    node = node->right;
                } else if (node->right == nullptr) {
                    node = node->left;
                }

                delete temp;
            } else {
                // Node has two children, find the in-order successor
                ThreadedBinaryTreeNode* successor = findSuccessor(node);
                node->data = successor->data;
                node->right = removeNode(node->right, successor->data);
            }
        }

        return node;
    }
public:
    ThreadedBinaryTree() : root(nullptr) {}

    // Function to insert a new node into the threaded binary tree
    void insert(int value) {
        if (root == nullptr) {
            root = new ThreadedBinaryTreeNode(value);
            return;
        }

        ThreadedBinaryTreeNode* current = root;
        while (true) {
            if (value < current->data) {
                if (current->left == nullptr) {
                    current->left = new ThreadedBinaryTreeNode(value);
                    current->left->right = current;
                    current->left->isThreaded = true;
                    return;
                } else {
                    current = current->left;
                }
            } else {
                if (current->isThreaded || current->right == nullptr) {
                    ThreadedBinaryTreeNode* newNode = new ThreadedBinaryTreeNode(value);
                    newNode->left = current;
                    newNode->right = current->right;
                    current->right = newNode;
                    current->isThreaded = false;
                    newNode->isThreaded = true;
                    return;
                } else {
                    current = current->right;
                }
            }
        }
    }

    // Function to perform in-order traversal of the threaded binary tree
    void inOrderTraversal() {
        inOrderTraversal(root);
        std::cout << std::endl;
    }

    // Function to perform pre-order traversal of the threaded binary tree
    void preOrderTraversal(ThreadedBinaryTreeNode* node) {
        if (node != nullptr) {
            std::cout << node->data << " ";
            preOrderTraversal(node->left);
            preOrderTraversal(node->right);
        }
    }

    // Function to perform post-order traversal of the threaded binary tree
    void postOrderTraversal(ThreadedBinaryTreeNode* node) {
        if (node != nullptr) {
            postOrderTraversal(node->left);
            postOrderTraversal(node->right);
            std::cout << node->data << " ";
        }
    }

    // Function to remove a value from the threaded binary tree
    void remove(int value) {
        root = removeNode(root, value);
    }

    // Function to search for a value in the threaded binary tree
    ThreadedBinaryTreeNode* search(int value) {
        ThreadedBinaryTreeNode* current = root;
        while (current != nullptr) {
            if (value == current->data) {
                return current;
            } else if (value < current->data) {
                current = current->left;
            } else {
                current = current->isThreaded ? nullptr : current->right;
            }
        }
        return nullptr; // Not found
    }

    // Function to find the in-order successor of a given value
    ThreadedBinaryTreeNode* findSuccessor(int value) {
        ThreadedBinaryTreeNode* node = search(value);
        return (node != nullptr) ? findSuccessor(node) : nullptr;
    }

    // Function to find the in-order predecessor of a given value
    ThreadedBinaryTreeNode* findPredecessor(int value) {
        ThreadedBinaryTreeNode* current = root;
        ThreadedBinaryTreeNode* predecessor = nullptr;

        while (current != nullptr) {
            if (value == current->data) {
                if (current->left != nullptr) {
                    predecessor = findMin(current->left);
                }
                break;
            } else if (value < current->data) {
                current = current->left;
            } else {
                predecessor = current;
                current = current->isThreaded ? nullptr : current->right;
            }
        }

        return predecessor;
    }

    // Function to find the node with the minimum value in the tree
    ThreadedBinaryTreeNode* findMin() {
        return (root != nullptr) ? findMin(root) : nullptr;
    }

    // Function to find the node with the maximum value in the tree
    ThreadedBinaryTreeNode* findMax() {
        ThreadedBinaryTreeNode* current = root;
        while (current != nullptr && !current->isThreaded) {
            current = current->right;
        }
        return current;
    }

    // Function to count the number of nodes in the threaded binary tree
    int countNodes(ThreadedBinaryTreeNode* node) {
        if (node == nullptr) {
            return 0;
        }
        return 1 + countNodes(node->left) + countNodes(node->right);
    }

    // Function to get the height of the threaded binary tree
    int getHeight(ThreadedBinaryTreeNode* node) {
        if (node == nullptr) {
            return 0;
        }
        int leftHeight = getHeight(node->left);
        int rightHeight = getHeight(node->right);
        return 1 + std::max(leftHeight, rightHeight);
    }

    // Function to clear the threaded binary tree
    void clear() {
        postOrderDelete(root);
        root = nullptr;
    }

    // Function to print the tree structure using in-order traversal
    void printTreeStructure(ThreadedBinaryTreeNode* node, int indent = 0) {
        if (node != nullptr) {
            printTreeStructure(node->right, indent + 4);
            for (int i = 0; i < indent; ++i) {
                std::cout << " ";
            }
            std::cout << node->data << "\n";
            printTreeStructure(node->left, indent + 4);
        }
    }

    // Function to display the threaded binary tree structure
    void displayTreeStructure() {
        printTreeStructure(root, 0);
    }

    ThreadedBinaryTreeNode* getRoot() {
      return root;
    }
};

int main() {
    ThreadedBinaryTree threadedTree;

    // Inserting elements into the threaded binary tree
    threadedTree.insert(5);
    threadedTree.insert(3);
    threadedTree.insert(8);
    threadedTree.insert(2);
    threadedTree.insert(4);
    threadedTree.insert(7);
    threadedTree.insert(9);

    // Performing in-order traversal
    std::cout << "In-Order Traversal: ";
    threadedTree.inOrderTraversal();

    // Performing pre-order traversal
    std::cout << "Pre-Order Traversal: ";
    threadedTree.preOrderTraversal(threadedTree.getRoot());
    std::cout << std::endl;

    // Performing post-order traversal
    std::cout << "Post-Order Traversal: ";
    threadedTree.postOrderTraversal(threadedTree.getRoot());
    std::cout << std::endl;

    // Searching for a value
    int searchValue = 4;
    ThreadedBinaryTreeNode* searchResult = threadedTree.search(searchValue);
    if (searchResult != nullptr) {
        std::cout << "Node with value " << searchValue << " found!" << std::endl;
    } else {
        std::cout << "Node with value " << searchValue << " not found." << std::endl;
    }

    // Finding the in-order successor
    int successorValue = 4;
    ThreadedBinaryTreeNode* successor = threadedTree.findSuccessor(successorValue);
    if (successor != nullptr) {
        std::cout << "In-order successor of " << successorValue << ": " << successor->data << std::endl;
    } else {
        std::cout << "No in-order successor found for " << successorValue << std::endl;
    }

    // Finding the in-order predecessor
    int predecessorValue = 7;
    ThreadedBinaryTreeNode* predecessor = threadedTree.findPredecessor(predecessorValue);
    if (predecessor != nullptr) {
        std::cout << "In-order predecessor of " << predecessorValue << ": " << predecessor->data << std::endl;
    } else {
        std::cout << "No in-order predecessor found for " << predecessorValue << std::endl;
    }

    // Finding the node with the minimum value
    ThreadedBinaryTreeNode* minNode = threadedTree.findMin();
    if (minNode != nullptr) {
        std::cout << "Node with minimum value: " << minNode->data << std::endl;
    } else {
        std::cout << "The tree is empty." << std::endl;
    }

    // Finding the node with the maximum value
    ThreadedBinaryTreeNode* maxNode = threadedTree.findMax();
    if (maxNode != nullptr) {
        std::cout << "Node with maximum value: " << maxNode->data << std::endl;
    } else {
        std::cout << "The tree is empty." << std::endl;
    }

    // Counting the number of nodes
    int nodeCount = threadedTree.countNodes(threadedTree.getRoot());
    std::cout << "Number of nodes in the tree: " << nodeCount << std::endl;

    // Getting the height of the tree
    int treeHeight = threadedTree.getHeight(threadedTree.getRoot());
    std::cout << "Height of the tree: " << treeHeight << std::endl;

    // Displaying the tree structure
    std::cout << "Tree Structure:\n";
    threadedTree.displayTreeStructure();

    // Clearing the tree
    threadedTree.clear();
    std::cout << "Tree cleared." << std::endl;

    return 0;
}
