#include <iostream>
using namespace std;

class NWGraph {
  private:
    bool** edges;
    int* data;
    int size;
  public:
    NWGraph(int size, int data[]) {
      this->size = size;
      data = new int [size];
      edges = new bool* [size];
      for (int i = 0 ; i < size ; i++) {
        edge[i] = new bool [size];
      }
      for (int i = 0; i < size ; i++) {
        this->data[i] = data[i];
      }
      for (int i = 0; i < size ; i++) {
        for (int j = 0 ; j < size ; j++) {
          this->edge[i][j] = 0;
        }
      }
    }
    
    ~NWGraph(){
      delete[] data;
      for (int i = 0 ; i < size ; i++) {
        delete[] edge[i];
      }
      delete[] edge;
    }
    
    void insert (int src, int dest, bool bi) {
      int srcIndex = findIndex(src);
      int destIndex = findIndex(dest);
      if (srcIndex == -1 || destIndex == -1){
        cout << "Not found" << endl;
        return;
      }
      edges[srcIndex][destIndex] = true;
      if(bi) {
        edges[destIndex][srcIndex] = true;
      }
    }
    
    void remove (int src, int dest, bool bi) {
      int srcIndex = findIndex(src);
      int destIndex = findIndex(dest);
      if (srcIndex == -1 || destIndex == -1){
        cout << "Not found" << endl;
        return;
      }
      edges[srcIndex][destIndex] = false;
      if(bi) {
        edges[destIndex][srcIndex] = false;
      }
    }
    
  
  
  private:
    int findIndex (int key) {
      for (int i = 0 ; i < size ; i++) {
        if(key == data[i]) {
          return i;
        }
      }
      return -1;
    }
};


int main () {
  return 0;
}