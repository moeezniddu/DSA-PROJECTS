#include <iostream>
using namespace std;
class ThreadedBSTNode {
public:
    int key;
    ThreadedBSTNode* leftChild;
    ThreadedBSTNode* rightChild;
    ThreadedBSTNode* rightThread;

    ThreadedBSTNode(int value) : key(value), leftChild(nullptr), rightChild(nullptr), rightThread(nullptr) {}
};

class ThreadedBST {
private:
    ThreadedBSTNode* root;

    // Helper function to find the leftmost node in a subtree
    ThreadedBSTNode* leftmost(ThreadedBSTNode* node) {
        while (node != nullptr && node->leftChild != nullptr) {
            node = node->leftChild;
        }
        return node;
    }

public:
    ThreadedBST() : root(nullptr) {}

    // Public method to perform in-order traversal
    void inOrderTraversal() {
        inOrderTraversalThreadedBST(root);
    }

    // Public method to insert a key into the TBST
    void insert(int key) {
        root = insertKey(root, key);
    }

    // Helper function to insert a key into the TBST
    ThreadedBSTNode* insertKey(ThreadedBSTNode* node, int key) {
        if (node == nullptr) {
            return new ThreadedBSTNode(key);
        }

        if (key < node->key) {
            node->leftChild = insertKey(node->leftChild, key);
            if (node->leftChild->rightThread == nullptr) {
                node->leftChild->rightThread = node;
            }
        } else if (key > node->key) {
            node->rightChild = insertKey(node->rightChild, key);
        }

        return node;
    }

    // Public method for proper memory cleanup
    void deleteTree() {
        deleteTree(root);
    }

    // Helper function for proper memory cleanup
    void deleteTree(ThreadedBSTNode* node) {
        if (node == nullptr) {
            return;
        }

        deleteTree(node->leftChild);
        deleteTree(node->rightChild);
        delete node;
    }

    // Private method to perform in-order traversal on TBST
    void inOrderTraversalThreadedBST(ThreadedBSTNode* root) {
        ThreadedBSTNode* current = leftmost(root);

        while (current != nullptr) {
            cout << current->key << " ";

            if (current->rightThread != nullptr) {
                current = current->rightThread;
            } else {
                current = leftmost(current->rightChild);
            }
        }
        cout << endl;
    }
};

int main() {
    ThreadedBST tbst;

    tbst.insert(4);
    tbst.insert(2);
    tbst.insert(6);
    tbst.insert(1);
    tbst.insert(3);
    tbst.insert(5);
    tbst.insert(7);

    cout << "In-Order Traversal:" << endl;
    tbst.inOrderTraversal();

    // Memory cleanup
    tbst.deleteTree();

    return 0;
}
